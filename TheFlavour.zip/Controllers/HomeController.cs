﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TheFlavour.Models;

namespace TheFlavour.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        private FlavourDBEntities dbo = new FlavourDBEntities();
        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult Slider()
        {
            var items = dbo.Slides;
            return PartialView(items);
        }

        public ActionResult NavMain()
        {
            return PartialView();
        }

        public ActionResult Container()
        {
            return PartialView();
        }

        public ActionResult PostMenu()
        {
            return PartialView();
        }

        public ActionResult NextMenu()
        {
            return PartialView();
        }

        public ActionResult ParallelSection()
        {
            return PartialView();
        }

        public ActionResult SpecialOffer()
        {
            return PartialView();
        }

        public ActionResult GridGallery()
        {
            return PartialView();
        }
        public ActionResult GoogleMap()
        {
            return PartialView();
        }
    }
}