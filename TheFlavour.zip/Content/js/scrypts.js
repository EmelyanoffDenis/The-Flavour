$(document).ready(function () {    
    $(".main_carousel").bxSlider({
        auto: true,
        pause: 7000,
        mode: 'fade',
        captions: true,
        speed: 2000
    });

    //������������ ���� ��� ���������
    $(".ref_discover").hover(function () {
        $(this).animate({ backgroundColor: 'rgba(255,255,255,0)' }, 200);
        $(".ref_discover a").animate({ color: '#FFF' }, 200);
    },
    function () {
        $(this).animate({ backgroundColor: 'rgba(255,255,255,1)' }, 200);
        $(".ref_discover a").animate({ color: '#000' }, 200);
    }
    )

    //For Next Menu
    $(".thumbnail").hover(function () {
        $("img", this).animate({
            opacity: 0.3
        });
        $(".for_animate", this).animate({
            marginTop: "35px"
        })
        $(".more_about_menu", this).fadeIn();
        $(".divider_up", this).animate({
            marginBottom: "15px"
        })
        $(".divider_down", this).animate({
            marginTop: "15px"
        })
    },
function () {
    $("img", this).animate({
        opacity: 1
    });
    $(".more_about_menu", this).fadeOut(200, function () {
        $(".for_animate", this).css("margin-top", "0px")
        $(".divider_up", this).css("margin-bottom", "50px")
        $(".divider_down", this).css("margin-top", "50px")
    });
})
    //For Parallel Section
    $("#findButton").hover(function () {
        $(this).animate({ backgroundColor: '#ffa42e' }, 200);
        $(".btnOrange").animate({ color: '#fff' }, 200);
    }, function () {
        $(this).animate({ backgroundColor: 'rgba(255,164,46,0)' }, 200);
        $(".btnOrange").animate({ color: '#ffa42e' }, 200);
    })
    //Parallax        
    //$('.parallax-section').scroolly([
    //  {
    //      from: 'el-top = vp-bottom + 100px',
    //      to: 'el-bottom = vp-center + 300px',
    //      cssFrom: { 'background-position': '50% 200px' },
    //      cssTo: { 'background-position': '50% 0px' }
    //  },
    //     {
    //         from: 'el-bottom = vp-center + 300px',
    //         to: 'el-bottom = vp-top + 100px',
    //         cssFrom: { 'background-position': '50% 0px' },
    //         cssTo: { 'background-position': '50% 0px' }
    //     },
    //]);

    //Parallax from Lena
    //$('body').scroll(); 

    $(window).scroll(function () {
        parallaxScroll();
    });

    function parallaxScroll() {
        var scrolled = $(window).scrollTop();
        //alert(scrolled);
        $('.parallax-section').css('background-position', 50 + '% ' + (200 - (scrolled * 0.15)) + 'px');
    }
    //Special Offer
    $(".btn-black-wrap").hover(function () {
        $(this).animate({ backgroundColor: '#000000' }, 200);
        $(".txt-btn-black").animate({ color: '#fff' }, 200);
        $(".btn-black").css("font-weight", "bold");
    }, function () {
        $(this).animate({ backgroundColor: 'rgba(255,164,46,0)' }, 200);
        $(".txt-btn-black").animate({ color: '#000000' }, 200);
        $(".btn-black").css("font-weight", "normal");
    })
    $(".post-thumbnail").hover(function () {
        $("img", this).animate({
            opacity: 0.3
        });
        $(".for-animate", this).fadeIn()
        $(".divider-up", this).animate({ marginBottom: "0px" })
        $(".divider-down", this).animate({ marginTop: "0px" })
        $(".more-about-offer", this).animate({ marginTop: "80px" })
    },
    function () {
        $("img", this).animate({
            opacity: 1
        });
        $(".for-animate", this).fadeOut(function () {
            $(".divider-up", this).css({ marginBottom: "50px" })
            $(".divider-down", this).css({ marginTop: "50px" })
            $(".more-about-offer").css({ marginTop: "30px" })
        })

    })

    $(".forJS").hover(function () {
        $(".forJS1", this).fadeIn();
        $(".grid-galley-col2").css("z-index", "auto");
    },
function () {
    $(".forJS1", this).fadeOut()
    $(".grid-galley-col2").css("z-index", "50");
}
);
    $(window).resize(function () {
        var w = $(window).width();
        if (w <= 1366) {
            $(".grid-gallery").css("height", "370px");
            $("#forPressRhomb").removeClass("rhomb");
            $("#forPressRhomb").addClass("rhomb-press");
            $("#rhomb-title-before").removeClass("rhomb-title-before");
            $("#rhomb-title-before").addClass("rhomb-title-before-press");
            $("#see-more").removeClass("see-more");
            $("#see-more").addClass("see-more-press");
            $("#rhomb-title").removeClass("rhomb-title");
            $("#rhomb-title").addClass("rhomb-title-press");
            $(".grid-gallery strong").css("font-size", "11px");
            $(".label-hide-box2").css("font-size", "11px");
            $(".wrap-in-ref").css("padding-top", "15%");
            $(".grid-galley-col2 .wrap-in-ref").css("padding-top", "8%")
            $(".grid-galley-col1 .wrap-in-ref").css("padding-top", "25%")
            $(".grid-galley-col4 .wrap-in-ref").css("padding-top", "30%")
            $(".MapCover").css("top", "4376px")
        }
        else {
            $(".grid-gallery").css("height", "726px");
            $("#forPressRhomb").removeClass("rhomb-press");
            $("#forPressRhomb").addClass("rhomb");
            $("#rhomb-title-before").removeClass("rhomb-title-before-press");
            $("#rhomb-title-before").addClass("rhomb-title-before");
            $("#see-more").removeClass("see-more-press");
            $("#see-more").addClass("see-more");
            $("#rhomb-title").removeClass("rhomb-title-press");
            $("#rhomb-title").addClass("rhomb-title");
            $(".grid-gallery strong").css("font-size", "100%");
            $(".label-hide-box2").css("font-size", "100%");
            $(".wrap-in-ref").css("padding-top", "30%");
            $(".MapCover").css("top", "4730px")
        }
    });
    $("#see-more").hover(function () {
        $(this).animate({ color: "#fff" });
    }, function () {
        $(this).animate({ color: "#ffa42e" });
    })
    //Google Map
    $("#MapButton").on("click", function () {
        $(".MapCover").fadeOut();
    })
});

